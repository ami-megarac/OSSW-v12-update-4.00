/* SPDX-License-Identifier: LGPL-2.1+ */
#pragma once

const char *arphrd_to_name(int id);
int arphrd_from_name(const char *name);
